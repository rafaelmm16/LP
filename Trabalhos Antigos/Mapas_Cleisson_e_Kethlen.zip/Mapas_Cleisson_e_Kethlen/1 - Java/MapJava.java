/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapjava;
import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;
/**
 *
 * @author cleison e kethlen
 */
public class MapJava {

    /**
     * @param args the command line arguments
     */


    public static void main(String[] args) {
        
         Scanner sc = new Scanner(System.in);
	 Map<String, Pessoa> mapPessoa = new HashMap<>();
         Pessoa dadosPessoa;
         int opcao;
         String cpf, lixo;
         
         do{
            menuPrincipal();
            opcao = sc.nextInt();
            switch(opcao)
            {
                case 1://Inserir dados
                    dadosPessoa = novoCadastro();
                    try{
                        mapPessoa.put(dadosPessoa.getCpf(), dadosPessoa);
                    }catch(Exception ex){
                        System.out.println("Não foi possível inserir esse registro. Tente novamente!");
                    }
                    break;
                case 2://Pesquisar uma chave e obter os dados associados
                    lixo = sc.nextLine();//recolhendo lixo causado 
                    System.out.print("Informe o CPF (chave) que deseja buscar: ");
                    cpf = sc.nextLine();
                    imprimirimprimir(buscaInformacao(mapPessoa,cpf));
                    break;
                case 3://Alterar dados
                    lixo = sc.nextLine();//recolhendo lixo causado                     
                    System.out.print("Informe o CPF (chave) que deseja buscar: ");
                    cpf = sc.nextLine();
                    alterarDados(mapPessoa,cpf);
                    break;
                case 4: //Remover registro
                    lixo = sc.nextLine();//recolhendo lixo causado                     
                    System.out.print("Informe o CPF (chave) que deseja remover: ");
                    cpf = sc.nextLine();
                    try{
                        mapPessoa.remove(cpf);
                    }catch(Exception ex){
                        System.out.println("Não foi possível apagar esse registro. Este CPF não consa nos registros.");
                    } 
                    break;
                case 5: //Quantidade de registros do MAP                  
                    System.out.println("Atualmente constam " + mapPessoa.size() + "elementos na base de dados.\n");    
                    break;
                case 6://imprimir 
                    if(mapPessoa.size()>0){
                        for(String cpfa:  mapPessoa.keySet()){
                            String chavee = cpfa.toString();
                            Pessoa pessoa = mapPessoa.get(chavee);
                            pessoa.imprimir();
                        }
                    }
                    else{
                        System.out.println("Nenhum cadastro encontrado!\n");
                    }       
                    break;
            }
         }while(opcao!=0);
            
    }
    
       public static  void menuPrincipal(){
            System.out.println("-------- MENU ------- ");
            System.out.println(" 1 - Inserir dados");
            System.out.println(" 2 - Pesquisar uma chave e obter os dados associados");
            System.out.println(" 3 - Alterar dados");
            System.out.println(" 4 - Remover registros");
            System.out.println(" 5 - Quantidade de registros do Map");
            System.out.println(" 6 - Imprimir Map");
            System.out.println(" 0 - SAIR");
            System.out.println("  --------  ------- ");
            System.out.println("Escolha uma opcao:\t");
    }

    private static Pessoa novoCadastro() {
        String nome;
        String cpf;
        String dataNascimento;
        String profissao;

        Scanner sc = new Scanner(System.in);
        //String lixo = sc.nextLine();//recolhendo lixo causado 

        System.out.print("Nome:\n");
        nome = sc.nextLine();
        System.out.print("CPF:\n");
        cpf = sc.nextLine();
        System.out.print("Data de nascimento:\n");
        dataNascimento = sc.nextLine();
        System.out.print("Profissão:\n");
        profissao = sc.nextLine();

        Pessoa novoDado = new Pessoa(nome, cpf, dataNascimento, profissao);
        return novoDado;
    }
    
    private static Pessoa buscaInformacao(Map<String, Pessoa> mapPessoa, String cpf){
        
        Pessoa pessoa = mapPessoa.get(cpf);
        if (pessoa == null) {
            System.out.println("CPF informado não consta na lista. Tente novamente!");
        }
        
        return pessoa;
    }
    
    
    private static void imprimirimprimir(Pessoa pessoa) {
        pessoa.imprimir();
    }
    
    private static  void menuAlterar()
    {
        System.out.println(" -------- Que informação deseja alterar ------- ");
        System.out.println(" 1 - Nome");
        System.out.println(" 2 - Data de nascimento");
        System.out.println(" 3 - CPF");
        System.out.println(" 4 - Profissão");
        System.out.println(" 0 - SAIR");
        System.out.println("  --------------- ");
        System.out.println("Escolha a opcao:\t");
    }

    private static void alterarDados(Map<String, Pessoa> mapPessoa, String cpf) {
         
        Pessoa pessoa = buscaInformacao(mapPessoa,cpf);
        int opcao2;
        String dado;
        Scanner sc = new Scanner(System.in);
        String lixo;
        
        menuAlterar();
        opcao2 = sc.nextInt(); 
        lixo = sc.nextLine();//recolhendo lixo causado 
        
        if(opcao2==1){
            System.out.println("Novo Nome: ");
            dado = sc.nextLine();
            pessoa.setNome(dado);}
        if(opcao2==2){
            System.out.println("Nova data de nascimento: ");
            dado = sc.nextLine();
            pessoa.setDataNascimento(dado);}
        if(opcao2==3){
            System.out.println("Novo CPF:");
            dado = sc.nextLine();
            mapPessoa.put(dado, new Pessoa(pessoa.getNome(), dado, pessoa.getDataNascimento(), pessoa.getProfissao()));
            mapPessoa.remove(cpf);
        }
        if(opcao2==4){
            System.out.println("Nova profissão:");
            dado = sc.nextLine();
            pessoa.setProfissao(dado);

        }else{ //caso não tenha um chave no 
              System.out.println("CPF informado não consta na lista. Tente novamente!\n");}
    }
}
