/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapjava;

import java.util.logging.Logger;

/**
 *
 * @author cleison e kethlen
 */
public class Pessoa {
    protected String nome;
    protected String cpf;
    protected String dataNascimento;
    protected String profissao;

    public Pessoa(String nome, String cpf, String dataNascimento, String profissao) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.profissao = profissao;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }
    
    public void imprimir() {
        System.out.println("Nome:       " + this.nome);
        System.out.println("CPF:        " + this.cpf);
        System.out.println("Nascimento: " + this.dataNascimento);
        System.out.println("Profissão:  " + this.profissao);
    }
}
