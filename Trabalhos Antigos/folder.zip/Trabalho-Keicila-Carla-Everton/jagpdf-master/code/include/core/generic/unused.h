// Copyright (c) 2005-2009 Jaroslav Gresula
//
// Distributed under the MIT license (See accompanying file
// LICENSE.txt or copy at http://jagpdf.org/LICENSE.txt)
//


#ifndef UNUSED_JG1921_H__
#define UNUSED_JG1921_H__

namespace jag {
namespace detail {

template <class T>
void ignore_unused(T const&) {}

}} // namespace jag::detail

#endif // UNUSED_JG1921_H__
/** EOF @file */
