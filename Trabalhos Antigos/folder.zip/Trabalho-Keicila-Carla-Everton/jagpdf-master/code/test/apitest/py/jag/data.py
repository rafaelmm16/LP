#!/usr/bin/env python

# Copyright (c) 2005-2009 Jaroslav Gresula
#
# Distributed under the MIT license (See accompanying file
# LICENSE.txt or copy at http://jagpdf.org/LICENSE.txt)
#


# names generator
#  http://www.neoprogrammics.com/randomisers/random_names_generator/

names_str="""Steven Eden
Madelyn E. Vinci
Corliss S. Widener
Terresa Dumond
Lean C. Willison
Man King
Bettina M. Haslam
Angele V. Heidelberg
James E. Satter
Maryjane Kunkel
Chara Y. Cyr
Suzanne S. Perrin
Emilia V. Noda
Aliza R. Charpentier
Neva Guida
Mariette L. Mcvay
Cristine Heid
Daisy Weidman
Tilda W. Trosclair
Jaunita Mathes
Janey Tidwell
Verline Migliore
Etta K. Staley
Yvone Pinedo
Alexander Gerner
Phung X. Vandenbosch
Karlene Sandusky
Gertrudis H. Newell
Emelia Mcninch
Khadijah M. Doyal
Hollie Donahoe
Debera M. Schley
Afton T. Blind
Fatimah K. Masson
Narcisa K. Pollitt
Leida C. Portillo
Adena Carranza
Angeline T. Honore
Dominga H. Clyburn
Tinisha L. Krol
Alene A. Antonelli
Jodee S. Yeomans
Eveline G. Hedley
Sherika Mcgeorge
Wei L. Mclaren
Aracelis M. Beets
Mina Nicholes
Stephaine D. Fishback
Kathie E. Otten
Arla Cannon
Janette Bolling
Nichelle G. Cronan
Lucina T. Severe
Nancy M. Moorman
Mandie Macdougall
Roxana Bancroft
Livia Wahl
Toshiko S. Fujiwara
Delinda J. Cascio
Margit L. Shore
China Mccurdy
Cris Wolfgang
Eartha A. Dorrance
Thu Florence
Nguyet J. Marchetti
Julianne D. Shadwick
Margherita R. Nimmons
Valorie Benevides
Scott C. Carolina
Ghislaine Johannes
Many R. Bosserman
Jeanice S. Arevalo
Lashaun A. Pritts
Leon M. Limon
Perry Nicklas
Harmony K. Levenson
Wendy Crosland
Luisa P. Lombardi
Roxie Quesenberry
Stephen M. Stell
Cristie A. Gries
Luanne P. Foshee
Jen N. Okelley
Lily P. Merryman
Wynell L. Hamrick
Harriette Greenhill
Evalyn Welter
Indira K. Goguen
Epifania Grabowski
Lou Espino
Nickie P. Guinn
Farrah M. Henthorn
Mathilde Fraley
Ling P. Duren
Fern E. Cloninger
Tony Goudeau
Jana Luker
Hue M. Bass
Kit Specht
Carmon Burgoon"""

names=names_str.split('\n')
