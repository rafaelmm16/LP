/*
 * Copyright (c) 2005-2009 Jaroslav Gresula
 *
 * Distributed under the MIT license (See accompanying file
 * LICENSE.txt or copy at http://jagpdf.org/LICENSE.txt)
 *
 */
#ifndef API_JG232_H__
#define API_JG232_H__

//#include <jagpdf/detail/capi.h>
#include "C:\Users\Nepeta\Desktop\TrabalhoLP-master pdf\TrabalhoLP-master\jagpdf-1.4.0.win32.x86.c_cpp\include\jagpdf\detail\capi.h"

//#include <jagpdf/detail/errcodes.h>
#include "C:\Users\Nepeta\Desktop\TrabalhoLP-master pdf\TrabalhoLP-master\jagpdf-1.4.0.win32.x86.c_cpp\include\jagpdf\detail\errcodes.h"
//#include <jagpdf/detail/version.h>
#include "C:\Users\Nepeta\Desktop\TrabalhoLP-master pdf\TrabalhoLP-master\jagpdf-1.4.0.win32.x86.c_cpp\include\jagpdf\detail\version.h"
#ifndef
/*# include <jagpdf/detail/cppapi.h>
#include "C:\Users\keici\Documents\GitHub\TrabalhoLP\jagpdf-1.4.0.win32.x86.c_cpp\include\jagpdf\detail\cppapi.h"*/
#endif

#endif
/** EOF @file */
