package Aula_10_09_2019;

public class Exercicios_10_09_2019 {
	public static void main(String[] args) {
		int x=5,y=9;
		int max;
		
		max = x > y ? x:y;
		System.out.println(x + "" + y + "Max recebeu " + max);
	}
}
