package union;

public class UnionClass {

}
